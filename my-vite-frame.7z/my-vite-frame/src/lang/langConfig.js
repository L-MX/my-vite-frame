const langConfig = [
  {value: 'zh_CN', label: '中文'}
]
export default langConfig
