export default {
  groups: [], // 分支
  errors: []  // 异常
}