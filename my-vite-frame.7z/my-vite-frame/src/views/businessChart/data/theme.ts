const theme = {
  // 边的样式
  polyline: {
    stroke: '#ccc',
    strokeWidth: 1
  }
};
export default theme
