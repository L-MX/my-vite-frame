import businessDialog from './business/index.vue'
export const TYPE_DIALOG_MAP = {
  business: 'businessDialog'
}

export const DialogComponents = {
  businessDialog
}
