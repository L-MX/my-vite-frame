<template>
  <div> 
    详情 
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>