<template>
    <div>
        前台页面
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>