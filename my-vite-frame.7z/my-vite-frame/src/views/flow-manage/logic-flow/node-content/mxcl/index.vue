<template>
    <div>
        模型处理节点
    </div>
</template>

<script setup lang="ts">

</script>

<style lang="scss" scoped>

</style>