/* 回复节点数据结构 */
export default {
  mainInfo: {
    voices: [],
  },
};
