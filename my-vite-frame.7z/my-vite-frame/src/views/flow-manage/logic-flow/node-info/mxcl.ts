/* 模型处理节点数据结构 */
export default {
  hintId: undefined, // 提示语id
  hintMessages: [], // 提示语信息
  hintOutputs: [], // 提示语输出内容结构化【需要存到变量-后台输出变量选项中】
};
